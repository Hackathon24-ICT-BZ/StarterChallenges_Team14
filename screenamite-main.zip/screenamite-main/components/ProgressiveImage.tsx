// ProgressiveImage.tsx
import React, { useState } from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import FastImage from 'react-native-fast-image';


interface ProgressiveImageProps {
  source: any;
  style?: any;
}

const ProgressiveImage: React.FC<ProgressiveImageProps> = ({ source, style }) => {
  const [loading, setLoading] = useState(true);

  return (
    <View style={[style, styles.imageContainer]}>
      {loading && <ActivityIndicator size="large" color="#0000ff" />}
      <FastImage
        style={style}
        source={source}
        onLoadEnd={() => setLoading(false)}
        resizeMode={FastImage.resizeMode.contain}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  imageContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default ProgressiveImage;
