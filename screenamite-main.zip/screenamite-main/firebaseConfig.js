// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore, collection, getDocs } from "firebase/firestore"; 
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAYTyq-XSkLMbhZhtFX4pAvVB6NU63PSVI",
  authDomain: "screenamite.firebaseapp.com",
  databaseURL: "https://screenamite-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "screenamite",
  storageBucket: "screenamite.appspot.com",
  messagingSenderId: "263769958456",
  appId: "1:263769958456:web:c86a1323b1e3c53f321ecd"
};

// Initialize Firebase

export function init() {
    const app = initializeApp(firebaseConfig);
    const db = getFirestore(app);
    return db;
  }