import psutil
import GPUtil
import json
import datetime
import os
import firebase_admin
from firebase_admin import credentials, db
from dotenv import load_dotenv


class PC:
    def __init__(self) -> None:
        self.cpu: float = 0
        self.gpu: float = 0
        self.ram: float = 0
        self.average: int = 0
        self.json: dict = {}

    def read(self) -> None:
        # get cpu & ram usage
        self.cpu = psutil.cpu_percent(1)
        self.ram = psutil.virtual_memory()[2]

        # get gpu usage
        gpus = GPUtil.getGPUs()
        self.gpu = sum([gpu.load for gpu in gpus]) / len(gpus) * 100

        # calculate total usage
        self.average = int(round((self.cpu * 100 + self.gpu * 100 + self.ram * 25) / 225))

        # make json dict & send to database
        self.json = self.make_json()
        ref = db.reference("/data")
        ref.update(self.json)

    def make_json(self) -> dict:
        time: str = str(datetime.datetime.now())[:19]
        image_paths: list[str] = self.get_urls()
        dictionary = {
            time: {
                "average": self.average,
                "cpu": self.cpu,
                "gpu": self.gpu,
                "ram": self.ram,
                "image_incredible": image_paths[0],
                "image_vegeta": image_paths[1],
                "image_pacman": image_paths[2]
            }
        }
        return dictionary

    def get_urls(self) -> list[str]:
        mapped: dict = {
            "incredible": [
                "https://firebasestorage.googleapis.com/v0/b/screenamite.appspot.com/o/images%2Fincredible%2Fincredible1.png?alt=media&token=cff4fd16-5461-4923-a16e-17c6f7e2a3b4",
                "https://firebasestorage.googleapis.com/v0/b/screenamite.appspot.com/o/images%2Fincredible%2Fincredible2.png?alt=media&token=9ae70a53-9b54-4a1f-b330-6ab3661f5382",
                "https://firebasestorage.googleapis.com/v0/b/screenamite.appspot.com/o/images%2Fincredible%2Fincredible3.png?alt=media&token=28fc7a99-ef83-441a-810d-6e4849e07f24",
                "https://firebasestorage.googleapis.com/v0/b/screenamite.appspot.com/o/images%2Fincredible%2Fincredible4.png?alt=media&token=4d0027e2-6ec9-42e7-9016-c95f2bb32b32",
                "https://firebasestorage.googleapis.com/v0/b/screenamite.appspot.com/o/images%2Fincredible%2Fincredible5.png?alt=media&token=09511376-fc44-49cf-9971-eafc1fea574d",
                "https://firebasestorage.googleapis.com/v0/b/screenamite.appspot.com/o/images%2Fincredible%2Fincredible6.png?alt=media&token=e9fdec1e-3253-474a-b2a9-9b0f57f20d0b",
                "https://firebasestorage.googleapis.com/v0/b/screenamite.appspot.com/o/images%2Fincredible%2Fincredible7.png?alt=media&token=34013ec3-93e8-4904-8f16-d04fb5baf873",
                "https://firebasestorage.googleapis.com/v0/b/screenamite.appspot.com/o/images%2Fincredible%2Fincredible8.png?alt=media&token=00cedc66-07f9-4f5b-8a05-bce8ba73db4c",
                "https://firebasestorage.googleapis.com/v0/b/screenamite.appspot.com/o/images%2Fincredible%2Fincredible9.png?alt=media&token=833c8533-a034-4c67-927d-560c5068888e",
                "https://firebasestorage.googleapis.com/v0/b/screenamite.appspot.com/o/images%2Fincredible%2Fincredible10.png?alt=media&token=70a69004-62cd-4524-8871-ed8f70b48d79"],
            "vegeta": [
                "https://firebasestorage.googleapis.com/v0/b/screenamite.appspot.com/o/images%2Fvegeta%2FVegeta_Loop_1_klein.gif?alt=media&token=f5e3bb71-a23d-41ab-89a7-65bd94e5f464",
                "https://firebasestorage.googleapis.com/v0/b/screenamite.appspot.com/o/images%2Fvegeta%2FVegeta_Loop_2_klein.gif?alt=media&token=b3537e38-0380-4102-84fd-a2f71ecd217a",
                "https://firebasestorage.googleapis.com/v0/b/screenamite.appspot.com/o/images%2Fvegeta%2FVegeta_Loop_3_klein.gif?alt=media&token=7c5fb651-824f-4b38-abf7-4af6a548f366",
                "https://firebasestorage.googleapis.com/v0/b/screenamite.appspot.com/o/images%2Fvegeta%2FVegeta_Loop_4_klein.gif?alt=media&token=5be2e075-b813-4275-8e50-337bb800b4b2",
                "https://firebasestorage.googleapis.com/v0/b/screenamite.appspot.com/o/images%2Fvegeta%2FVegeta_Loop_5_klein.gif?alt=media&token=55a48408-58f0-4a9a-b5d5-0c038eb911de"],
            "pacman": [
                "pacman1",
                "pacman2",
                "pacman3",
                "pacman4",
                "pacman5"]}

        index_10 = min(self.average // 10, 9)
        return [mapped["incredible"][index_10], mapped["vegeta"][index_10 // 2], mapped["pacman"][index_10 // 2]]


def init_firebase():
    load_dotenv()
    cred = credentials.Certificate(json.loads(os.getenv("FIREBASE_CRED_JSON")))
    firebase_admin.initialize_app(cred, {
        "databaseURL": "https://screenamite-default-rtdb.europe-west1.firebasedatabase.app/",
        "storageBucket": "screenamite.appspot.com"
    })


def main():
    pc = PC()
    init_firebase()

    while True:
        pc.read()


if __name__ == '__main__':
    main()
