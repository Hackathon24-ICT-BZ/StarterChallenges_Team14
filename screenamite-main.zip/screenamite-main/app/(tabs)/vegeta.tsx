import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, ActivityIndicator } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { getDatabase, onValue, ref } from "firebase/database";
import * as firebase from '@/firebaseConfig';

const AnimationScreen = () => {
  firebase.init();

  interface DataItem {
    timestamp: string;
    cpu: number;
    ram: number;
    gpu: number;
    image: string;
  }

  const [latestData, setLatestData] = useState<DataItem | null>(null);
  const [loading, setLoading] = useState(true);
  const navigation = useNavigation();

  const handleButton = () => {
    navigation.goBack();
  };

  useEffect(() => {
    fetchData(); // Fetch data on component mount
  }, []);

  function fetchData() {
    const db = getDatabase();
    const itemsRef = ref(db, 'data');
    onValue(itemsRef, (snapshot) => {
      const items = snapshot.val();
      let latestTimestamp = null;
      let latestEntry = null;

      for (let timestamp in items) {
        if (!latestTimestamp || new Date(timestamp) > new Date(latestTimestamp)) {
          latestTimestamp = timestamp;
          latestEntry = {
            timestamp,
            cpu: items[timestamp].cpu,
            ram: items[timestamp].ram,
            gpu: items[timestamp].gpu,
            image: items[timestamp].image_vegeta,
          };
        }
      }

      if (latestEntry) {
        setLatestData(latestEntry);
      }
    });
  }

  return (
    <View style={styles.container}>
      {/* Custom Header with Icon */}
      <TouchableOpacity style={styles.iconContainer} onPress={handleButton}>
        <Ionicons name="arrow-back" size={24} color="black" />
      </TouchableOpacity>

      {latestData && (
        <>
          <View style={styles.imageContainer}>
            {loading && (
              <ActivityIndicator size="large" color="#0000ff" style={styles.loadingIndicator} />
            )}
            <Image
              source={{ uri: latestData.image }}
              style={styles.image}
              onLoadStart={() => setLoading(true)}
              onLoadEnd={() => setLoading(false)}
            />
          </View>
          <View style={styles.line} />
          <View style={styles.table}>
            <View style={styles.row}>
              <Text style={styles.cell}>CPU Usage:</Text>
              <Text style={styles.cell}>{latestData.cpu.toFixed(1)}%</Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.cell}>GPU Usage:</Text>
              <Text style={styles.cell}>{latestData.gpu.toFixed(1)}%</Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.cell}>RAM Usage:</Text>
              <Text style={styles.cell}>{latestData.ram.toFixed(1)}%</Text>
            </View>
          </View>
        </>
      )}

      {!latestData && (
        <Text style={styles.placeholderText}>Loading data...</Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  iconContainer: {
    position: 'absolute',
    top: 40,
    left: 20,
    zIndex: 1,
  },
  imageContainer: {
    width: 500,
    height: 500,
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    width: 500,
    height: 500,
    resizeMode: 'contain',
  },
  line: {
    width: '90%',
    height: 2,
    backgroundColor: '#000',
    marginVertical: 20,
  },
  table: {
    width: '90%',
    padding: 10,
    backgroundColor: '#fff',
    borderRadius: 5,
    elevation: 3,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 5,
  },
  cell: {
    fontSize: 16,
  },
  placeholderText: {
    textAlign: 'center',
    fontSize: 18,
    marginVertical: 20,
  },
  loadingIndicator: {
    position: 'absolute',
    alignSelf: 'center',
  },
});

export default AnimationScreen;
