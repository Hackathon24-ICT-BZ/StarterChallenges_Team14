import { Image, StyleSheet, Platform, TouchableOpacity, GestureResponderEvent, useColorScheme, Button } from 'react-native';

import { HelloWave } from '@/components/HelloWave';
import ParallaxScrollView from '@/components/ParallaxScrollView';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';
import { TabBarIcon } from '@/components/navigation/TabBarIcon';
import { Colors } from 'react-native/Libraries/NewAppScreen';
import { router } from 'expo-router';


export default function HomeScreen() {
  const colorScheme = useColorScheme();



  function handleButtonIncredible(event: GestureResponderEvent): void {
    router.navigate("./incredible")
  }

  function handleButtonVegeta(event: GestureResponderEvent): void {
    router.navigate("./vegeta")
  }

  function handleButtonPacman(event: GestureResponderEvent): void {
    router.navigate("./pacman")
  }

  return (
    <ParallaxScrollView
      headerBackgroundColor={{ light: '#FFFFF', dark: '#00000' }}
      headerImage={
        <Image
          source={require('@/assets/images/banner.jpg')}
        />
      }>
      <ThemedView style={styles.titleContainer}>
        <ThemedText type="title">Screenamite <HelloWave /></ThemedText>
      </ThemedView>

      <ThemedView style={styles.titleContainer}>
        <ThemedText type="subtitle">Probier's doch aus</ThemedText>

      </ThemedView>

      <TouchableOpacity style={styles.button} onPress={handleButtonVegeta}>
        <ThemedText style={styles.white}>Vegeta</ThemedText>
      </TouchableOpacity>

      <TouchableOpacity style={styles.button} onPress={handleButtonIncredible}>
        <ThemedText style={styles.white}>Incredible</ThemedText>
      </TouchableOpacity>

      <TouchableOpacity style={styles.button} onPress={handleButtonPacman}>
        <ThemedText style={styles.white}>Pacman</ThemedText>
      </TouchableOpacity>

      
    </ParallaxScrollView>
  );
}

const styles = StyleSheet.create({
  titleContainer: {
    marginTop: 36,
    flexDirection: 'column',
    alignItems: "center",
    gap: 8,
  },
  stepContainer: {
    gap: 8,
    marginBottom: 8,
  },
  addButton: {
    position: 'absolute',
    bottom: 20,
    left: '50%',
    marginLeft: -30,
    zIndex: 5,
  },
  button: {
    marginTop: 16,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 12,
    paddingHorizontal: 32,
    borderRadius: 4,
    backgroundColor: "#1E90FF",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  
  buttonText: {
    fontSize: 16,
    color: "#0000",
    fontWeight: "bold",
    textTransform: "uppercase",
  },

  white: {
    color: "#FFFFFF",
  }
});
